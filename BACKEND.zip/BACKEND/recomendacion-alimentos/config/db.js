require('dotenv').config();
const { Sequelize } = require('sequelize');

// Conexión a PostgreSQL usando Sequelize
const sequelize = new Sequelize(process.env.DB_URI, {
    dialect: 'postgres',
    logging: false, // Desactiva el log de SQL si no lo necesitas
});

sequelize.authenticate()
    .then(() => console.log('Conexión a la base de datos establecida con éxito.'))
    .catch(err => console.error('No se pudo conectar a la base de datos:', err));

module.exports = sequelize;
