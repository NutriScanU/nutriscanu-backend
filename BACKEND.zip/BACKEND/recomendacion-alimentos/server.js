require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const swaggerUi = require('swagger-ui-express');
const yaml = require('yamljs');
const authRoutes = require('./routes/authRoutes');
const sequelize = require('./config/db');

// Cargar la documentación de Swagger
const swaggerDocument = yaml.load('./swagger.yaml');

const app = express();

// Middleware
app.use(bodyParser.json());
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// Rutas
app.use('/api/auth', authRoutes);

// Iniciar el servidor y conectar a la base de datos
sequelize.sync().then(() => {
  app.listen(process.env.PORT || 5000, () => {
    console.log(`Servidor corriendo en el puerto ${process.env.PORT || 5000}`);
  });
});
