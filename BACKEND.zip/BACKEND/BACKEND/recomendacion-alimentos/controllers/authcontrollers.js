const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/user');

// Registro de usuario
const register = async (req, res) => {
    try {
        const { first_name, last_name, middle_name, document_number, email, password } = req.body;

        // Verificar si el usuario ya existe
        const userExist = await User.findOne({ where: { document_number } });
        if (userExist) {
            return res.status(400).json({ error: 'El número de documento ya está registrado.' });
        }

        // Encriptar la contraseña
        const hashedPassword = await bcrypt.hash(password, 10);

        // Crear el nuevo usuario
        const newUser = await User.create({
            first_name,
            last_name,
            middle_name,
            document_number,
            email,
            password: hashedPassword,
        });

        return res.status(201).json({ message: 'Usuario registrado con éxito.' });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Error al registrar el usuario.' });
    }
};

// Login de usuario
const login = async (req, res) => {
    try {
        const { document_number, password } = req.body;

        // Buscar al usuario por el número de documento
        const user = await User.findOne({ where: { document_number } });
        if (!user) {
            return res.status(400).json({ error: 'Usuario no encontrado.' });
        }

        // Verificar la contraseña
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ error: 'Contraseña incorrecta.' });
        }

        // Generar JWT
        const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });

        return res.status(200).json({ token });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Error al iniciar sesión.' });
    }
};

module.exports = { register, login };
